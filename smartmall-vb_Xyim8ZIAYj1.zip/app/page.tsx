import { Header } from "@/components/header"
import { CategoryNav } from "@/components/category-nav"
import { ProductGrid } from "@/components/product-grid"
import { AIAssistant } from "@/components/ai-assistant"
import { BottomNav } from "@/components/bottom-nav"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background pb-20">
      <Header />
      <main className="container mx-auto px-4 py-4 max-w-6xl">
        <CategoryNav />
        <ProductGrid />
      </main>
      <AIAssistant />
      <BottomNav />
    </div>
  )
}
