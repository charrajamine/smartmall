"use client"

import { useState } from "react"
import { Home, Search, Heart, User } from "lucide-react"
import { Button } from "@/components/ui/button"

const navItems = [
  { id: "home", label: "Home", icon: Home },
  { id: "search", label: "Search", icon: Search },
  { id: "favorites", label: "Favorites", icon: Heart },
  { id: "profile", label: "Profile", icon: User },
]

export function BottomNav() {
  const [active, setActive] = useState("home")

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-30">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="grid grid-cols-4 gap-1 py-2">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = active === item.id
            return (
              <Button
                key={item.id}
                variant="ghost"
                className={`flex flex-col items-center gap-1 h-auto py-2 ${
                  isActive ? "text-primary" : "text-muted-foreground"
                }`}
                onClick={() => setActive(item.id)}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs">{item.label}</span>
              </Button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
