import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product-card"

const products = [
  {
    id: 1,
    name: "iPhone 15 Pro",
    price: "999",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.8,
    reviews: 1234,
  },
  {
    id: 2,
    name: "Samsung Galaxy S24",
    price: "899",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.7,
    reviews: 987,
  },
  {
    id: 3,
    name: "Google Pixel 8",
    price: "699",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.6,
    reviews: 756,
  },
  {
    id: 4,
    name: "OnePlus 12",
    price: "799",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.5,
    reviews: 543,
  },
  {
    id: 5,
    name: "Xiaomi 14 Pro",
    price: "649",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.4,
    reviews: 432,
  },
  {
    id: 6,
    name: "Nothing Phone 2",
    price: "599",
    image: "/placeholder.svg?height=200&width=200",
    rating: 4.3,
    reviews: 321,
  },
]

export function ProductGrid() {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">Featured Products</h2>
        <Button variant="ghost" size="sm" className="text-primary">
          View All
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  )
}
