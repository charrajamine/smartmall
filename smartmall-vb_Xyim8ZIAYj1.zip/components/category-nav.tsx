"use client"

import { useState } from "react"
import { Smartphone, Laptop, Headphones, Watch } from "lucide-react"
import { Button } from "@/components/ui/button"

const categories = [
  { id: "phones", label: "Phones", icon: Smartphone },
  { id: "laptops", label: "Laptops", icon: Laptop },
  { id: "accessories", label: "Accessories", icon: Headphones },
  { id: "wearables", label: "Wearables", icon: Watch },
]

export function CategoryNav() {
  const [activeCategory, setActiveCategory] = useState("phones")

  return (
    <div className="mb-6">
      <h2 className="text-lg font-semibold mb-3">Categories</h2>
      <div className="grid grid-cols-4 gap-2">
        {categories.map((category) => {
          const Icon = category.icon
          return (
            <Button
              key={category.id}
              variant={activeCategory === category.id ? "default" : "outline"}
              className="flex flex-col items-center gap-2 h-auto py-3"
              onClick={() => setActiveCategory(category.id)}
            >
              <Icon className="h-5 w-5" />
              <span className="text-xs">{category.label}</span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}
